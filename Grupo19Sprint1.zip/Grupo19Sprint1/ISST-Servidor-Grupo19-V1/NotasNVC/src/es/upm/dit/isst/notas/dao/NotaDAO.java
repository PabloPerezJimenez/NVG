package es.upm.dit.isst.notas.dao;

import java.util.List;
import es.upm.dit.isst.notas.model.Nota;

public interface NotaDAO {
	
	public List<Nota> listNotas();
	public void add (String title, String body, Double x, Double y);
	public void remove (String title);

}