package es.upm.dit.isst.notas;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.google.appengine.labs.repackaged.org.json.JSONException;
import com.google.appengine.labs.repackaged.org.json.JSONObject;

import es.upm.dit.isst.notas.dao.NotaDAO;
import es.upm.dit.isst.notas.dao.NotaDAOImpl;
import es.upm.dit.isst.notas.model.Nota;

public class JsonSendServlet extends HttpServlet {
	
	public void doGet(HttpServletRequest req, HttpServletResponse resp)
			throws IOException, ServletException {
		
		
	  
		NotaDAO per = NotaDAOImpl.getInstance();
		List<Nota> notas = new ArrayList<Nota>();
		notas = per.listNotas();
		
		resp.setContentType("application/json");
		PrintWriter out = resp.getWriter();
		JSONObject jsonObject = new JSONObject();
		try {
			for(Nota c : notas){
			jsonObject.put(c.getTitle(), c.getBody());
			
			
			
			}
		} catch (JSONException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		System.out.println(jsonObject);
		out.print(jsonObject);
		out.flush();
		
	}

}
