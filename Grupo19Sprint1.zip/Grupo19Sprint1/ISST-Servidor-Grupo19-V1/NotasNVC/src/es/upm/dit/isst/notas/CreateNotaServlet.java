package es.upm.dit.isst.notas;

import java.io.BufferedReader;
import java.io.IOException;


import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


import es.upm.dit.isst.notas.dao.NotaDAO;
import es.upm.dit.isst.notas.dao.NotaDAOImpl;



public class CreateNotaServlet extends HttpServlet {
	
	private static final long serialVersionUID = 1L;

	public void doPost(HttpServletRequest req, HttpServletResponse resp)
			throws IOException {
		
		

		System.out.println("Creando Nota");
		StringBuffer jb = new StringBuffer();
		String line = null;
		try {
			
			BufferedReader reader = req.getReader();
			while ((line = reader.readLine()) != null){
				System.out.println("Leyendo buffer");
				jb.append(line);
			}

			String name = jb.toString().substring(11, jb.toString().indexOf("\",\"cuerpo"));
			System.out.println(name);
			String body = jb.toString().substring(jb.toString().indexOf("\",\"cuerpo") + 12, jb.toString().indexOf("\"}"));
			System.out.println(body);
			

			NotaDAO per = NotaDAOImpl.getInstance();
			per.add(name, body, 0.0, 0.0);
			

		} catch (Exception e) { 
			e.printStackTrace();        
		}

	}


}
