package es.upm.dit.isst.notas;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import java.util.logging.Logger;

import es.upm.dit.isst.notas.dao.NotaDAO;
import es.upm.dit.isst.notas.dao.NotaDAOImpl;
import es.upm.dit.isst.notas.model.Nota;







import com.google.appengine.api.users.User;
import com.google.appengine.api.users.UserService;
import com.google.appengine.api.users.UserServiceFactory;
import com.google.appengine.labs.repackaged.org.json.JSONException;
import com.google.appengine.labs.repackaged.org.json.JSONObject;



public class MainServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private static Logger LOGGER = Logger.getLogger("InfoLogging");

	public void doGet(HttpServletRequest req, HttpServletResponse resp)
			throws IOException, ServletException {
		
		LOGGER.info("Req: " +req);
	  
		NotaDAO per = NotaDAOImpl.getInstance();
		List<Nota> notas = new ArrayList<Nota>();
		notas = per.listNotas();
		
		
		
		
		req.getSession().setAttribute("notas", new ArrayList<Nota>(notas));
		RequestDispatcher view = req.getRequestDispatcher("NotaApplication.jsp");
        view.forward(req, resp);
	}
}