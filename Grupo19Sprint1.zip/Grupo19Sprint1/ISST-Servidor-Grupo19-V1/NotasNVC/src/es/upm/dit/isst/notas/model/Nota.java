package es.upm.dit.isst.notas.model;


import java.io.Serializable;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

@Entity
public class Nota implements Serializable {


	private static final long serialVersionUID = 1L;
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id;
	private String title;

	private String body;
	private Double coordX;
	private Double coordY;

	public Nota(String title , String body, Double x, Double y) {
		this.title = title;
		this.body = body;
		this.coordX = x;
		this.coordY = y;
		
	}

	public Long getId() {
		return id;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public String getBody() {
		return body;
	}

	public void setBody(String body) {
		this.body = body;
	}


	public Double getCoordX() {
		return coordX;
	}
	
	public void setCoordX(Double x) {
		this.coordX = x;
	}

	public Double getCoordY() {
		return coordY;
	}
	
	public void setCoordY(Double y) {
		this.coordY = y;
	}
	
} 

