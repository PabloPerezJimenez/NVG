package es.upm.dit.isst.notas.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.Query;

import es.upm.dit.isst.notas.model.Nota;

public class NotaDAOImpl implements NotaDAO {

	private static NotaDAOImpl instance;

	private NotaDAOImpl() {
	}

	public static NotaDAOImpl getInstance(){
		if (instance == null)
			instance = new NotaDAOImpl();
		return instance;
	}


	@Override
	public List<Nota> listNotas() {
		EntityManager em = EMFService.get().createEntityManager();
		// read the existing entries
		Query q = em.createQuery("select m from Nota m");
		List<Nota> notas = q.getResultList();
		return notas;
	}

	@Override
	public void add(String title, String body, Double x, Double y) {
		synchronized (this) {
			EntityManager em = EMFService.get().createEntityManager();
			Nota nota = new Nota(title, body, x, y);
			em.persist(nota);
			em.close();
		}

	}

	

	@Override
	public void remove(String title) {
		EntityManager em = EMFService.get().createEntityManager();
		try {
			Nota todo = em.find(Nota.class, title);
			em.remove(todo);
		} finally {
			em.close();
		}
	}

	
}
