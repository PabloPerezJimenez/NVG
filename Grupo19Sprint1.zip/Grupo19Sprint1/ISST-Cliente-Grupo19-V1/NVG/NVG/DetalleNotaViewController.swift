//
//  DetalleNotaViewController.swift
//  NVG
//
//  Created by g266 DIT UPM on 13/3/15.
//  Copyright (c) 2015 g299 DIT UPM. All rights reserved.
//

import UIKit
import Foundation
import MapKit

class DetalleNotaViewController: UIViewController {
    
    var nombre : String?
    var cuerpo : String?
    
    @IBOutlet weak var nombreNota: UILabel!
    
    @IBOutlet weak var cuerpoNota: UITextView!
    
    @IBOutlet weak var mapa: MKMapView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        
                // Ponemos aqui nuestra localizacion.
                let location = CLLocationCoordinate2D(
                    latitude : 40.452398,
                    longitude : -3.726358
                )
                // Aqui ponemos el zoom que queremos en el mapa. 1 Grado son 111Km
                let span = MKCoordinateSpanMake(0.02, 0.02)
                //Aqui decimos que centren la region en nuestra localización, con la anchura que declaramos en span.
                let region = MKCoordinateRegion(center: location, span: span)
                //Creamos la region en el mapa.
                mapa.setRegion(region, animated: true)
        
                //Le damos valores al postit que nos aparecerá, dandole titulo o cuerpo del texto.
                let annotation = MKPointAnnotation()
                    annotation.setCoordinate(location)
                    annotation.title = "Big Ben"
                    annotation.subtitle = "London"
                //Añado la anotación al mapa.
                mapa.addAnnotation(annotation)
                
                nombreNota.text = nombre
                cuerpoNota.text = cuerpo

    }
    
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    
}