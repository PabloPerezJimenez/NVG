//
//  InicioTableViewController.swift
//  NVG
//
//  Created by g299 DIT UPM on 13/3/15.
//  Copyright (c) 2015 g299 DIT UPM. All rights reserved.
//

import Foundation
import MapKit
import UIKit
import CoreLocation


class InicioTableViewController: UITableViewController, CLLocationManagerDelegate  {
    
    
    //var mapa: MKMapView!
    var latitud: Float!
    var longitud: Float!
    var localizacion: CLLocationCoordinate2D!
    var locationManager : CLLocationManager!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        if UIDevice.currentDevice().userInterfaceIdiom == .Pad {
            self.clearsSelectionOnViewWillAppear = false
            self.preferredContentSize = CGSize(width: 320.0, height: 600.0)
        }
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
//        locationManager? = CLLocationManager()
//        locationManager.requestAlwaysAuthorization()
//        locationManager.delegate = self
//        locationManager.desiredAccuracy = kCLLocationAccuracyBest
//        locationManager.requestAlwaysAuthorization()
//        locationManager.startUpdatingLocation()
        
      //  mapa.showsUserLocation = true
        
        //        let userLocation = mapa.userLocation
        //
        //        let span = MKCoordinateSpanMake(0.02, 0.02)
        //        let region = MKCoordinateRegion(center: userLocation.coordinate, span: span)
        //        mapa.setRegion(region, animated: false)
        
        
        
        
        
        //Codigo para mostrar una localización determinada.
        
        
        
        //        // Ponemos aqui nuestra localizacion.
        //        let location = CLLocationCoordinate2D(
        //            latitude: 51.50007773,
        //            longitude: -0.1246402
        //        )
        //        // Aqui ponemos el zoom que queremos en el mapa. 1 Grado son 111Km
        //        let span = MKCoordinateSpanMake(0.02, 0.02)
        //        //Aqui decimos que centren la region en nuestra localización, con la anchura que declaramos en span.
        //        let region = MKCoordinateRegion(center: location, span: span)
        //        //Creamos la region en el mapa.
        //        mapa.setRegion(region, animated: true)
        //
        //        //Le damos valores al postit que nos aparecerá, dandole titulo o cuerpo del texto.
        //        let annotation = MKPointAnnotation()
        //            annotation.setCoordinate(location)
        //            annotation.title = "Big Ben"
        //            annotation.subtitle = "London"
        //        //Añado la anotación al mapa.
        //        mapa.addAnnotation(annotation)
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    override func tableView(tableView: UITableView, numberOfRowsInSection section: Int) -> Int {

        return 1
    }
    
    override func tableView(tableView: UITableView, cellForRowAtIndexPath indexPath: NSIndexPath) -> CeldaInicial {
        
        let cell = tableView.dequeueReusableCellWithIdentifier("celdaInicial", forIndexPath: indexPath) as CeldaInicial
        
        var num : Int
        num = indexPath.row
        var numString = String(num)

        
        latitud = 40.452398
        longitud = -3.726358
       // println("jajajajajajaja")
        let center = CLLocationCoordinate2D(latitude: CLLocationDegrees(latitud), longitude: CLLocationDegrees(longitud))
        let span = MKCoordinateSpanMake(0.001, 0.001)
        var reg =  MKCoordinateRegionMake(center, span)
        
        cell.mapView.setRegion(reg, animated: true)
        let annotation = MKPointAnnotation()
            annotation.setCoordinate(center)
            annotation.title = "Estas aquí"
            annotation.subtitle = ":-D"
        cell.mapView.addAnnotation(annotation)
        cell.mapView.mapType = .Hybrid
        cell.mapView.userInteractionEnabled = true
        
        return cell
    }
    
    
    override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {
        
        if segue.identifier == "Show Notes" {
            
            println("jojojojojojojoj")
            // El destino del segue es el Navigation Controller.
            // El primer VC apuntado por el Navigation Controller el WebVC.
            let wvc = segue.destinationViewController as NotasTableViewController
            println("jajajajajajaja")
            
            wvc.locationUs = localizacion
            // sender es la celda de la tabla que disparo el segue.
//            if let ip = tableView.indexPathForCell(sender! as UITableViewCell) {
//                println("jejejejejejeje")
//                //let type = pokedexModel.types[ip.section]
//                
//                //               wvc.tipo = pokedexModel.types[ip.row]
//                //wvc.typeNum = ip.row
//                
//                wvc.navigationItem.leftBarButtonItem = self.splitViewController?.displayModeButtonItem()
//                wvc.navigationItem.leftItemsSupplementBackButton = true
//            }
        }
    }
    
    func goToRoot(){
    }
    
}


