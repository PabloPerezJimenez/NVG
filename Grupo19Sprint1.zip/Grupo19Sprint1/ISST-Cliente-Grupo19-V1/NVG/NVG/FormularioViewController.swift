//
//  FormularioViewController.swift
//  NVG
//
//  Created by Eloy Cepa Andres on 14/03/15.
//  Copyright (c) 2015 g299 DIT UPM. All rights reserved.
//

import Foundation
import UIKit

class FormularioViewController: UIViewController{

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    //let url = NSURL(string: "http://notasnvc.appspot.com")
    
    @IBOutlet weak var Nombre: UITextField!
    @IBOutlet weak var CuerpoNota: UITextField!
    
    @IBAction func SubirNota(sender: AnyObject) {
        
        // statusLabel.text = "Subiendo Nota"
        
        UIApplication.sharedApplication().networkActivityIndicatorVisible = true
        
        //Datos a subir 
        
        let VirtualNote = ["nombre":Nombre.text, "cuerpo":CuerpoNota.text]
        
        var error : NSError?
        let dataNote = NSJSONSerialization.dataWithJSONObject(VirtualNote, options: .allZeros, error: &error)
        
        //  URL Destino:
        
        let NOTES_URL = "http://notasnvc.appspot.com/new"
        let escapedNoteUrl = NOTES_URL.stringByAddingPercentEscapesUsingEncoding(NSUTF8StringEncoding)!
        
        let url = NSURL(string: escapedNoteUrl)
        
        // La peticion HTTP:
        let request = NSMutableURLRequest(URL: url!)
        request.HTTPMethod = "POST"
        request.addValue("application/json; charset=utf-8", forHTTPHeaderField: "Content-Type")
        
        //  La sesion
        let sessionConf = NSURLSessionConfiguration.ephemeralSessionConfiguration()
        let session = NSURLSession(configuration: sessionConf)
        
        // La tarea para subir datos
        // El tercer parametro es el completionHandler pero se esta usando como una Trailing Closure
        
        let uploadTask = session.uploadTaskWithRequest(request, fromData: dataNote){(data:NSData!, response: NSURLResponse!, error: NSError!) -> Void in

            let res = response as NSHTTPURLResponse
            
            // EL completionHandler no corre en el Main Thread
            dispatch_async(dispatch_get_main_queue(),{
                
                if error != nil {
                  println("Error mira el la pagina 38 pa ver cual es (traspas 121)")
                } else if res.statusCode != 200 && res.statusCode != 201 {
                    let code = res.statusCode
                    let msg = NSHTTPURLResponse.localizedStringForStatusCode(code)
                    println(msg)
                } else {
                    println("Nota Subida con Exito!!!!!!")
                    self.Nombre.text = ""
                    self.CuerpoNota.text = ""
                }
                UIApplication.sharedApplication().networkActivityIndicatorVisible = false
                
                })
        }
        uploadTask.resume()
    }
        
        
    
    
}