//
//  CeldaInicial.swift
//  NVG
//
//  Created by g299 DIT UPM on 13/3/15.
//  Copyright (c) 2015 g299 DIT UPM. All rights reserved.
//

import Foundation
import MapKit
import UIKit

class CeldaInicial: UITableViewCell{
    
    
    @IBOutlet weak var mapView: MKMapView!
    
}