//
//  NotasTableViewController.swift
//  NVG
//
//  Created by g266 DIT UPM on 10/3/15.
//  Copyright (c) 2015 NVGteam. All rights reserved.
//

import Foundation
import UIKit
import CoreLocation


class NotasTableViewController: UITableViewController{

//    required init(coder aDecoder: NSCoder) {
//        fatalError("init(coder:) has not been implemented")
//    }
//    
    // lazy var pokedexModel = PokedexModel()
    var numeroNota : Int?
    var count : Int?
    var distanciaNota : Int?
    var nombre : String?
    var cuerpo : String?
    var locationManager : CLLocationManager!
    var locationUs : CLLocationCoordinate2D!
    
    var listaNotas = [String:String] ()
    var arrayNombres = []

    
    
    let NOTA_URL = "http://notasnvc.appspot.com/json"
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
       downloadNotes()
        
        
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    // MARK: - Table view data source
    
    /*override func numberOfSectionsInTableView(tableView: UITableView) -> Int {
    return pokedexModel.types.count
    }*/
    
    override func tableView(tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        
        
        //let type = pokedexModel.types[section]

        return listaNotas.count
    }
    
    private func downloadNotes() {
        
        
        let str = NOTA_URL
        
        if let str = str.stringByAddingPercentEscapesUsingEncoding(NSUTF8StringEncoding) {
            
            if let url = NSURL(string: str) {
                
                let queue = dispatch_queue_create("Descargando datos", DISPATCH_QUEUE_SERIAL)
                dispatch_async(queue, {
                    
                    UIApplication.sharedApplication().networkActivityIndicatorVisible = true
                    
                    if let data = NSData(contentsOfURL: url) {
                        
                        var err: NSError?
                        if let dic = NSJSONSerialization.JSONObjectWithData(data, options: NSJSONReadingOptions.allZeros, error: &err) as?  [String:String] {
                            
                            dispatch_async(dispatch_get_main_queue(), {
                                //self.updateOutlets(dic)
                                println(dic)
                                self.listaNotas=dic
                                self.arrayNombres = self.listaNotas.keys.array
                                self.tableView.reloadData()
                            })
                        } else {
                            println("No puedo sacar el JSON")
                        }
                    } else {
                        println("Error: no se han podido descargar los datos.")
                    }
                    
                    UIApplication.sharedApplication().networkActivityIndicatorVisible = false
                })
            } else {
                println("Error: URL mal formada")
            }
        } else {
            println("Error escapando URL")
        }
    }
    

    
    override func tableView(tableView: UITableView, cellForRowAtIndexPath indexPath: NSIndexPath) -> UITableViewCell {
        
        let cell = tableView.dequeueReusableCellWithIdentifier("celda", forIndexPath: indexPath) as UITableViewCell
        
        
        cell.textLabel?.text = toString(arrayNombres[indexPath.row])
        cell.detailTextLabel?.text = listaNotas[toString(arrayNombres[indexPath.row])]
        
        
        
        return cell
    }

    
    
    
    override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {
        
        if segue.identifier == "Celda Detalle" {
            
          
            // El destino del segue es el Navigation Controller.
            // El primer VC apuntado por el Navigation Controller el WebVC.
            let wvc = segue.destinationViewController as DetalleNotaViewController
        
            // sender es la celda de la tabla que disparo el segue.
            if let ip = tableView.indexPathForCell(sender! as UITableViewCell) {
              
              
            
            wvc.nombre = toString(arrayNombres[ip.row])
            wvc.cuerpo = listaNotas[toString(arrayNombres[ip.row])]

                
                wvc.navigationItem.leftBarButtonItem = self.splitViewController?.displayModeButtonItem()
                wvc.navigationItem.leftItemsSupplementBackButton = true
            }
        }
    }
    
}
